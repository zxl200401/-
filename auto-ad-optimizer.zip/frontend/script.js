function generateAd() {
    fetch('http://127.0.0.1:5000/generate_ad', {
        method: 'POST',
    })
    .then(response => response.json())
    .then(data => {
        const adContent = `
            <h3>${data.headline}</h3>
            <p>${data.description}</p>
            <img src="${data.image_url}" alt="Ad Image">
        `;
        document.getElementById('ad-content').innerHTML = adContent;
    })
    .catch(error => console.error('Error:', error));
}
